import numpy as np

# Set seed for reproducibility
np.random.seed(1)

# Generate random matrices A and B of size 5x5
A = np.random.rand(5, 5)
B = np.random.rand(5, 5)

# Compute the determinant of A + B, det(A), and det(B)
det_A_plus_B = np.linalg.det(A + B)
det_A = np.linalg.det(A)
det_B = np.linalg.det(B)
print(det_A_plus_B)
print(det_A)
print(det_B)

# Compute det(A + B) - det(A) - det(B)
diff = det_A_plus_B - det_A - det_B

print("det(A + B) - det(A) - det(B) =", diff)