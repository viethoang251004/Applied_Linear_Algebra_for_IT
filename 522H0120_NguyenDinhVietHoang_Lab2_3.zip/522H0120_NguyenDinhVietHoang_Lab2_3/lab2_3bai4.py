import numpy as np

A = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])  # create matrix A
B = np.flipud(A)  # flip matrix A vertically to create matrix B
print(B)