import numpy as np

A = np.array([[2, 4, 5/2], [-3/4, 2, 1/4], [1/4, 1/2, 2]])
B = np.array([[1, -1/2, 3/4], [3/2, 1/2, -2], [1/4, 1, 1/2]])

A_inv = np.linalg.inv(A)
B_inv = np.linalg.inv(B)

# (A**(-1))(B**(-1))
AB_inv = np.dot(A_inv, B_inv)
print("AB_inv:\n", AB_inv)

# (AB)**(-1)
AB = np.dot(A, B)
AB_inv2 = np.linalg.inv(AB)
print("AB_inv2:\n", AB_inv2)

# (BA)**(-1)
BA = np.dot(B, A)
BA_inv = np.linalg.inv(BA)
print("BA_inv:\n", BA_inv)

# (A**(-1))**T
A_inv_T = A_inv.T
print("A_inv_T:\n", A_inv_T)

# (A**T)**(-1)
A_T = A.T
A_T_inv = np.linalg.inv(A_T)
print("A_T_inv:\n", A_T_inv)