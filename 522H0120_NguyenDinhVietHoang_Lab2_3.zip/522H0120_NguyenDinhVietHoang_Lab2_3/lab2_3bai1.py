import numpy as np

#(a)
a = np.array([1, 2, 3, 4, 5])
A = np.tile(a, (5, 1))
print(A)

#(b)
b = np.array([1,2,3,4,5,6])
B = np.tile(b, (6, 1))
print(B)

#(c)
c = np.arange(1, 31)   # create vector c with values 1 to 30
C = c.reshape(5, 6)    # reshape c to a 5x6 matrix
print(C)

#(d)
d = np.arange(1, 26)   # create vector d with values 1 to 25
D = d.reshape(5, 5)    # reshape d to a 5x5 matrix
print(D)