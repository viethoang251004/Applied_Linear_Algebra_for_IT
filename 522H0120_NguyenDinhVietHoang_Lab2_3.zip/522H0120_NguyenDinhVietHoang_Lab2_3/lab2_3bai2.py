import numpy as np

a = 0   # lower bound
b = 10  # upper bound
random_matrix = np.random.randint(low=a, high=b+1, size=(5, 6))
print(random_matrix)