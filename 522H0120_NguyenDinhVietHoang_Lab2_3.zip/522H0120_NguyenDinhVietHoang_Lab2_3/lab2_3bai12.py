import numpy as np

# Matrix A
A = np.array([[6, 0, 0, 5], [1, 7, 2, -5], [2, 0, 0, 0], [8, 3, 1, 8]])
det_A = np.linalg.det(A)
print("det(A) =", det_A)

# Matrix B
B = np.array([[1, -2, 5, 2], [0, 0, 3, 0], [2, -6, -7, 5], [5, 0, 4, 4]])
det_B = np.linalg.det(B)
print("det(B) =", det_B)

# Matrix C
C = np.array([[3, 5, -8, 4], [0, -2, 3, -7], [0, 0, 1, 5], [0, 0, 0, 2]])
det_C = np.linalg.det(C)
print("det(C) =", det_C)

# Matrix D
D = np.array([[4, 0, 0, 0], [7, -1, 0, 0], [2, 6, 3, 0], [5, -8, 4, -3]])
det_D = np.linalg.det(D)
print("det(D) =", det_D)

# Matrix E
E = np.array([[4, 0, -7, 3, -5], [0, 0, 2, 0, 0], [7, 3, -6, 4, -8], [5, 0, 5, 2, -3], [0, 0, 9, -1, 2]])
det_E = np.linalg.det(E)
print("det(E) =", det_E)

# Matrix F
F = np.array([[6, 3, 2, 4, 0], [9, 0, -4, 1, 0], [8, -5, 6, 7, 1], [3, 0, 0, 0, 0], [4, 2, 3, 2, 0]])
det_F = np.linalg.det(F)
print("det(F) =", det_F)