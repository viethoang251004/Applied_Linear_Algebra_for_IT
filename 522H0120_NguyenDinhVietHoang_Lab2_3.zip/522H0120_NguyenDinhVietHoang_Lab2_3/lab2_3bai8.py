import numpy as np

# Define the sales data as a 3x5 numpy array
sales_data = np.array([[12, 15, 10, 16, 12],
                       [5, 9, 14, 7, 10],
                       [8, 12, 10, 9, 15]])

# Define the prices of each ice cream flavor
strawberry_price = 2
vanilla_price = 1
chocolate_price = 3

# Calculate the total sales for each day
total_sales = (sales_data[0] * strawberry_price) + (sales_data[1] * vanilla_price) + (sales_data[2] * chocolate_price)

# Print the total sales for each day
print("Total sales for each day:")
print("Monday: $", total_sales[0])
print("Tuesday: $", total_sales[1])
print("Wednesday: $", total_sales[2])
print("Thursday: $", total_sales[3])
print("Friday: $", total_sales[4])