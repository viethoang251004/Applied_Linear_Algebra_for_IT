import numpy as np

A = np.array([[2, 7, 9, 7],
              [3, 1, 5, 6],
              [8, 1, 2, 5]])

#(a)
B = A[:, 1::2].flatten()
print(B)

#(b)
C = A[::2, :].flatten()
print(C)

#(c)
A_new = A[:, :-1]
print(A_new)