import numpy as np

x = np.array([3, 11, -9, -131, -1, 1, -11, 91, -6, 407, -12, -11, 12, 153, 371])

#(a)
max_val = np.max(x)
print(max_val)

#(b)
min_val = np.min(x)
print(min_val)

#(c)
indices = np.where(x > 10)[0]
print(indices)

#(d)
reversed_x = x[::-1]
print(reversed_x)

#(e)
sorted_x = sorted(x)
print(sorted_x)

#(f)
x_desc = sorted(x, reverse=True)
print(x_desc)

#(g)
count = 0
for i in range(len(x)):
    for j in range(i+1, len(x)):
        if x[i] + x[j] == 0:
            count += 1
print(count)

#(h)
num_duplicates = len(x) - len(set(x))
print(num_duplicates)

#(i)
n = len(x)
y = [x[i] + x[n-i-1] for i in range(n)]
print(y)

#(j)
w = [n for n in x if n >= 0 and n == sum(int(digit)**len(str(n)) for digit in str(n))]
print(w)

#(k)
z = [n for n in x if n >= 0]
print(z)

#(l)
n = len(x)
sorted_x = sorted(x)
if n % 2 == 0:
    median = (sorted_x[n//2-1] + sorted_x[n//2]) / 2
else:
    median = sorted_x[n//2]
print(median)

#(m)
mean = sum(x) / len(x)
sum_less_than_mean = sum([n for n in x if n < mean])
print(sum_less_than_mean)

#(n)
new_x = [abs(n) if n < 0 else n for n in x]
print(new_x)