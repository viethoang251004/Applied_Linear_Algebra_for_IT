import numpy as np

x = np.array([0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20])

#(a)
first_six = x[:6]
print(first_six)

#(b)
last_five = x[-5:]
print(last_five)

#(c)
indices = [0, 3, -1]
selected = x[indices]
print(selected)

#(d)
indices1 = [0, 2, 4, 6]
selected1 = x[indices1]
print(selected1)

#(e)
indices2 = np.arange(1, len(x), 2)
selected2 = x[indices2]
print(selected2)

#(f)
indices3 = np.arange(0, len(x), 2)
selected3 = x[indices3]
print(selected3)