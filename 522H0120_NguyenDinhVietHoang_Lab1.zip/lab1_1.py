import numpy as np

x = np.array([1, 3, 5, 2, 9])
y = np.array([-1, 3, 15, 27, 29])

n_x = len(x)
n_y = len(y)

print("Number of elements in x: ", n_x)
print("Number of elements in y: ", n_y)