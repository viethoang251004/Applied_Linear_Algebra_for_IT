import numpy as np
n = int(input("Enter the n = "))
x1 = np.logspace(1, n, n)
print(x1)