import numpy as np
x = np.array([1, 2, 3])
y = np.array([98, 12, 33])
z = np.concatenate((x, y))
print(z)