import numpy as np

#a
n = int(input('Enter the number of elements: '))
b = [i for i in range(12, 2*n+11, 2)]
print(b)

#b
n = int(input('Enter the number of elements: '))
c = [i for i in range(31, 2*n+29, 2)]
print(c)

#c
n = int(input('Enter the number of elements: '))
x = int(n/2)
x = np.arange(-x,x+1,1)
print(x)

#d
n = int(input('Enter the number of elements: '))
y = int(n/2)
y = np.arange(y,-(y+1),-1)
print(y)

#e
n = int(input("Enter the number of elements: "))   # get the number of elements from the user
z = [10 - 2*i for i in range(n)]   # create the list using a list comprehension
print(z)

#f
n = int(input("Enter the number of elements: "))   # get the number of elements from the user
w = [1/2**i for i in range(n)]   # create the list using a list comprehension
print(w)

#g
n = int(input("Enter the number of elements: "))   # get the number of elements from the user
d = [1] * n   # create a list of n elements with all elements initialized to 1
a, b = 1, 1   # initialize two variables to 1
for i in range(2, n):
    c = a + b   # compute the next element in the series
    d[i] = 1/c   # update the corresponding element in the list
    a, b = b, c   # update the variables a and b for the next iteration
print(d)

#h
n = int(input("Enter the number of elements: "))
e = [1/p for p in range(2, 2+n) if all(p % d != 0 for d in range(2, int(p**0.5)+1))]
print(e)

#i
n = int(input("Enter the number of elements: "))
a = [(i*(i+1))//2 for i in range(1, n+1)]
print(a)

#j
r = int(input("Enter the number of elements: "))
n = [1/(2*i + 1) for i in range(r)]
print(n)

#k
n = int(input("Enter the number of elements: "))
p = [i/(i+1) for i in range(n)]
print(p)

#l
n = int(input("Enter the number of elements: "))
o = [chr(i) for i in range(ord('a'), ord('a')+n)]
print(o)

#m
n = int(input("Enter the number of elements: "))
s = ['A' + chr(i) for i in range(68, 68 + n*3, 3)]
print(s)