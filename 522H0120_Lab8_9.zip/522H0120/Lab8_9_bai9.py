import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the house image
house_image = cv2.imread('house.jpg')

# Define the translation parameters
tx = 2
ty = 4

# Perform translation
translated_image = cv2.warpAffine(house_image, np.float32([[1, 0, tx], [0, 1, ty]]), (house_image.shape[1], house_image.shape[0]))

# Define the rotation parameter
alpha = np.pi / 3

# Perform rotation
rotation_matrix = cv2.getRotationMatrix2D((house_image.shape[1] / 2, house_image.shape[0] / 2), np.degrees(alpha), 1)
rotated_image = cv2.warpAffine(house_image, rotation_matrix, (house_image.shape[1], house_image.shape[0]))

# Define the scaling parameters
Sx = 2
Sy = 3

# Perform scaling
scaled_image = cv2.resize(house_image, None, fx=Sx, fy=Sy)

# Define the shear parameters
Shearx = 0.5
Sheary = -1.5

# Perform shear
shear_matrix_x = np.float32([[1, Shearx, 0], [0, 1, 0]])
sheared_image_x = cv2.warpAffine(house_image, shear_matrix_x, (house_image.shape[1], house_image.shape[0]))

shear_matrix_y = np.float32([[1, 0, 0], [Sheary, 1, 0]])
sheared_image_y = cv2.warpAffine(house_image, shear_matrix_y, (house_image.shape[1], house_image.shape[0]))

# Display the original and transformed images
fig, axes = plt.subplots(2, 3, figsize=(12, 8))

axes[0, 0].imshow(cv2.cvtColor(house_image, cv2.COLOR_BGR2RGB))
axes[0, 0].set_title('Original House')

axes[0, 1].imshow(cv2.cvtColor(translated_image, cv2.COLOR_BGR2RGB))
axes[0, 1].set_title('Translated House')

axes[0, 2].imshow(cv2.cvtColor(rotated_image, cv2.COLOR_BGR2RGB))
axes[0, 2].set_title('Rotated House')

axes[1, 0].imshow(cv2.cvtColor(scaled_image, cv2.COLOR_BGR2RGB))
axes[1, 0].set_title('Scaled House')

axes[1, 1].imshow(cv2.cvtColor(sheared_image_x, cv2.COLOR_BGR2RGB))
axes[1, 1].set_title('Sheared House (X)')

axes[1, 2].imshow(cv2.cvtColor(sheared_image_y, cv2.COLOR_BGR2RGB))
axes[1, 2].set_title('Sheared House (Y)')

for ax in axes.flat:
    ax.axis('off')

plt.tight_layout()
plt.show()
