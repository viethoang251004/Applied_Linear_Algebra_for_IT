import numpy as np
import matplotlib.pyplot as plt

# (a)
x = np.array([0, 1, 2, 3])
y = np.array([1, 1, 2, 2])

A = np.vstack([np.ones(len(x)), x]).T
a0, a1 = np.linalg.lstsq(A, y, rcond=None)[0]

print("Equation: y = {} + {}x".format(a0, a1))

plt.scatter(x, y, label="Data Points")
plt.plot(x, a0 + a1 * x, color="red", label="Least Squares Line")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.show()

# (b)
x = np.array([1, 2, 4, 5])
y = np.array([0, 1, 2, 3])

A = np.vstack([np.ones(len(x)), x]).T
a0, a1 = np.linalg.lstsq(A, y, rcond=None)[0]

print("Equation: y = {} + {}x".format(a0, a1))

plt.scatter(x, y, label="Data Points")
plt.plot(x, a0 + a1 * x, color="red", label="Least Squares Line")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.show()

# (c)
x = np.array([-1, 0, 1, 2])
y = np.array([0, 1, 2, 4])

A = np.vstack([np.ones(len(x)), x]).T
a0, a1 = np.linalg.lstsq(A, y, rcond=None)[0]

print("Equation: y = {} + {}x".format(a0, a1))

plt.scatter(x, y, label="Data Points")
plt.plot(x, a0 + a1 * x, color="red", label="Least Squares Line")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.show()

# (d)
x = np.array([2, 3, 5, 6])
y = np.array([3, 2, 1, 0])

A = np.vstack([np.ones(len(x)), x]).T
a0, a1 = np.linalg.lstsq(A, y, rcond=None)[0]

print("Equation: y = {} + {}x".format(a0, a1))

plt.scatter(x, y, label="Data Points")
plt.plot(xaray, a0 + a1 * x, color="red", label="Least Squares Line")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.show()
