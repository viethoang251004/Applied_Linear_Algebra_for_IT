import numpy as np

A = np.array([[0, 0, 1],
              [0, 1, 1],
              [1, 2, 1],
              [1, 0, 1],
              [4, 1, 1],
              [4, 2, 1]])

b = np.array([0.5, 1.6, 2.8, 0.8, 5.1, 5.9])

ATA = np.dot(A.T, A)
ATb = np.dot(A.T, b)

x = np.linalg.solve(ATA, ATb)

print("Least square solutions:")
print(x)
