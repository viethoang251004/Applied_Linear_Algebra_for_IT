from sympy import symbols, Eq, solve

x, y, z, t = symbols('x y z t')

eq1 = Eq(2*x - 4*y + 4*z + 0.077*t, 3.86)
eq2 = Eq(-2*y + 2*z - 0.056*t, -3.47)
eq3 = Eq(2*x - 2*y, 0)

sol = solve((eq1, eq2, eq3), (x, y, z, t))

print(sol)