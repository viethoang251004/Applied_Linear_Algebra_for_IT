import numpy as np

A = np.array([[3, 3.2], [3.5, 3.6]])

B = np.array([118.4, 135.2])

result = np.linalg.solve(A, B)

print("Number of children:", round(result[0]))
print("Number of adults:", round(result[1]))