import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

x_value = np.arange(-10, 10.1, 1)


def plot2D_Equation(x_value, a, b, c):
    if b == 0:
        if a == 0:
            print("Khong ve duoc bieu do")
        else:
            num = len(x_value)
            x_value_new = np.full(num, c/a)
            y_value = np.linspace(-10, 10, num)
            plt.plot(x_value_new, y_value, "r")
    else:
        def y(x): return (c - a*x)/b
        y_value = list(map(y, x_value))
        plt.plot(x_value, y_value, "b")

# (a)
plot2D_Equation(x_value, 1, 1, 5)
plot2D_Equation(x_value, 2, 2, 12)
plt.title("The system has no solution.")
plt.show()

# (b)
plot2D_Equation(x_value, 1, 1, 0)
plot2D_Equation(x_value, 1, -1, 2)
plt.title("The system has a unique solution.")
plt.show()

#(c)
plot2D_Equation(x_value, 1, 1, 5)
plot2D_Equation(x_value, 3, 3, 15)
plt.title("The system has infinitely many solutions.")
plt.show()