#Bài 3
import matplotlib.pyplot as plt
import numpy as np
def plotEquation3D(ax, x_arr, a, b, c, d, color):
  """
  This function plots the linear equation ax + by + cz = d in a 3D coordinate system.
  ax: axes
  x_arr: values on the x-axis
  color: color of the graph
  """
  if c != 0:
    z_func = lambda x, y: (d - a*x - b*y) / c
    y_arr = x_arr.copy()
    X,Y = np.meshgrid(x_arr, y_arr) #a grid of points created from all combinations of x-values and y-values
    Z = z_func(X, Y) # evaluation of the z-function on the grid
    ax.plot_surface(X, Y, Z, color = color)
  else:
    #Google search "python plot a 2D line in 3d"
    if b != 0:
      y_func = lambda x: (d - a*x)/b 
      y_arr = list( map(y_func, x_arr) )
      ax.plot(x_arr, y_arr, zdir='z', zs=-50, color=color)
      #print(y_arr)
    else:
      if a != 0:
        x_arr_new = np.full(len(x_arr), d/a)
        y_arr = np.linspace(-10, 10, num = len(x_arr)) #values -10 10 need to be modified based on the linear system
        ax.plot(x_arr_new, y_arr, zdir='z', zs=-50, color=color)
      else:
        print("Cannot plot this function!")
#Call Function Plot3D:
#Firstly, we manually create x-values on the x-axis as follows:
x_arr = np.arange(-10, 10.1, 0.1)
fig = plt.figure()
ax= fig.add_subplot(projection= '3d')
plt.title("Has no Solution")
plotEquation3D(ax, x_arr, 25, 5, 1, 106.8, "blue")
plotEquation3D(ax, x_arr, 64, 8, 1, 177.2, "green")
plotEquation3D(ax, x_arr, 144, 12, 1, 279.2, "red")

x_arr = np.arange(-10, 10.1, 0.1)
fig = plt.figure()
ax= fig.add_subplot(projection= '3d')
plt.title("Unique Solution")
plotEquation3D(ax, x_arr, 4, 2, 1, 106.8, "blue")
plotEquation3D(ax, x_arr, 24, 12, 6, 177.2, "green")
plotEquation3D(ax, x_arr, 72, 36, 18, 279.2, "red")

x_arr = np.arange(-10, 10.1, 0.1)
fig = plt.figure()
ax= fig.add_subplot(projection= '3d')
plt.title("Infinitely many solutions")
plotEquation3D(ax, x_arr, 4, 2, 1, 0, "white")
x_arr = np.arange(-8, 8, 0.1)
plotEquation3D(ax, x_arr, 24, 12, 6, 0, "yellow")
x_arr = np.arange(-6, 6, 0.1)
plotEquation3D(ax, x_arr, 72, 36, 18, 0, "black")