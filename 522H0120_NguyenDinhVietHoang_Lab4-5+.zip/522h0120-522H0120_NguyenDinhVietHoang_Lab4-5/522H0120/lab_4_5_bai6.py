import numpy as np

x = np.array([1, 2, 3])
y = np.array([6, 15, 38])

coeffs = np.polyfit(x, y, 2)

a2, a1, a0 = coeffs

print(f"p(t) = {a0} + {a1}t + {a2}t^2")