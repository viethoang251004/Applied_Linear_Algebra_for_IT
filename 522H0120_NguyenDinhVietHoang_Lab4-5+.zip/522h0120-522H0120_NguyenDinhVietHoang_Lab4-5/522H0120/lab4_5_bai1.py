import numpy as np
import sympy as sp

# (a)
A = np.array([[1, 2, 1],
              [2, -1, 1],
              [2, 1, 0]])

B = np.array([[0],
              [0],
              [0]])

X = np.linalg.solve(A, B)

# print solution
print("x = ", X[0])
print("y = ", X[1])
print("z = ", X[2])

# (b)
C = np.array([[2, 1, 1, 1],
              [1, 2, 1, 1],
              [1, 1, 2, 2],
              [1, 1, 1, 2]])

D = np.array([[1],
              [1],
              [1],
              [1]])

X = np.linalg.solve(C, D)

print("x = ", X[0])
print("y = ", X[1])
print("z = ", X[2])
print("t = ", X[3])
