import numpy as np

A = np.array([[0.61, 0.29, 0.15],
              [0.35, 0.59, 0.063],
              [0.04, 0.12, 0.787]])

CIE_data = np.array([[0.5],
                     [0.3],
                     [0.2]])

RGB_data = np.dot(A, CIE_data)

print(RGB_data)