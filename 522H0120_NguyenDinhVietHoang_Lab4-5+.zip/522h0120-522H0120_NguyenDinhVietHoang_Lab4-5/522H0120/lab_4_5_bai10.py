import numpy as np

A = np.array([[0.25, 0.15, 0.1], [0.4, 0.15, 0.2], [0.15, 0.2, 0.2]])
d = np.array([100, 100, 100]).reshape(3, 1)

I = np.eye(3)
p = np.linalg.inv(I - A) @ d

print("The production vector p is:\n", p)