#Bài 11
import sympy as sp
x1, x2, x3, x4 = sp.symbols('x1, x2, x3, x4')
t1 = 3*x1 - x3
t2 = 8*x1 - 2*x4
t3 = 2*x2 - 2*x3 - x4
#defineing equations
pt1 = sp.Eq(t1, 0)
pt2 = sp.Eq(t2, 0)
pt3 = sp.Eq(t3, 0)
#ep2 = sp/Eq =(x + y, 2)

sol = sp.solve((pt1, pt2, pt3), (x1, x2, x3, x4))
print(sol)
print("End")
print("C3H8 + 5O2 ----> 5CO2 + 4H2O")

#Cách 2
print("Cách 2")
import numpy as np
from sympy.solvers.solveset import linsolve
x1, x2, x3, x4 = sp.symbols('x1, x2, x3, x4')
# Danh sách các dạng phương trình:
X = linsolve([3*x1 - x3, 8*x1 - 2*x4, 2*x2 - 2*x3 - x4], (x1, x2, x3, x4))
print("Ex11: X = ",X)