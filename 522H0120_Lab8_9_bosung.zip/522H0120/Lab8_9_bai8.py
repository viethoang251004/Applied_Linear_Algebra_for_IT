import numpy as np

R = np.array([[np.cos(np.pi), -np.sin(np.pi)],
              [np.sin(np.pi), np.cos(np.pi)]])

# (a)
vector_a = np.array([1, 0])
result_a = R.dot(vector_a)

# (b)
vector_b = np.array([1, 0])
result_b = R.dot(vector_b)

print("Result (a):", result_a)
print("Result (b):", result_b)
