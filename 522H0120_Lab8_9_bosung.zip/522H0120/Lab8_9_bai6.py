import numpy as np
import matplotlib.pyplot as plt

time = np.array([1, 2, 3, 4, 5, 6])
grams = np.array([2.1, 3.5, 4.2, 3.1, 4.4, 6.8])

A = np.vstack([time**3, time**2, time, np.ones(len(time))]).T

coefficients = np.linalg.lstsq(A, grams, rcond=None)[0]

a, b, c, d = coefficients

x = np.linspace(1, 6, 100)
y = a*x**3 + b*x**2 + c*x + d

plt.scatter(time, grams, label="Data Points")
plt.plot(x, y, color="red", label="Cubic Model")
plt.xlabel("Time (Days)")
plt.ylabel("Grams")
plt.legend()
plt.show()
