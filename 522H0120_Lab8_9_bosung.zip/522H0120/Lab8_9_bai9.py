import numpy as np
import matplotlib.pyplot as plt
a = np.array([[-1, -1, -1.5, -1, 0.4, 0.4, 0.7, 0.7, 1, 1.5, 1, 1, 0, 0, -0.5, -0.5, -1],
              [0, 1, 1, 2, 2, 2.5, 2.5, 2, 2, 1, 1, 0, 0, 0.7, 0.7, 0, 0]])
#cau a
dx = 2 
dy = 4  
translation_matrix = np.array([[dx], [dy]])
b = a + translation_matrix

plt.figure()
plt.plot(a[0],a[1],'bo-')
plt.plot(b[0], b[1], 'ro-')
plt.title('Graph ex a')
plt.xlabel('x')
plt.ylabel('y')
plt.show()
#cau b
goc = np.pi / 3
rotatedMatrix = np.array([[np.cos(goc), np.sin(goc)],[-np.sin(goc), np.cos(goc)]])
b = np.matmul(rotatedMatrix,a)
plt.plot(a[0],a[1],'bo-')
plt.plot(b[0], b[1], 'ro-')
plt.title('Graph ex b')
plt.xlabel('x')
plt.ylabel('y')
plt.show()

#cau c
Sx = 2
Sy = 3
xS = a[0] * Sx
yS = a[1] * Sy
b = np.array([xS,yS])
plt.plot(a[0],a[1],'bo-')
plt.plot(b[0], b[1], 'ro-')
plt.title('Graph ex c')
plt.xlabel('x')
plt.ylabel('y')
plt.show()

#cau d
xshearMatrix = np.array([[1, 0.5], [0,1]])
b = np.matmul(xshearMatrix, a)
plt.plot(a[0],a[1],'bo-')
plt.plot(b[0], b[1], 'ro-')
plt.title('Graph ex d along x')
plt.xlabel('x')
plt.ylabel('y')
plt.show()

xshearMatrix = np.array([[1, 0], [1.5, 1]])
b = np.matmul(xshearMatrix, a)
plt.plot(a[0],a[1],'bo-')
plt.plot(b[0], b[1], 'ro-')
plt.title('Graph ex d along y')
plt.xlabel('x')
plt.ylabel('y')
plt.show()