import numpy as np

S = np.array([[2, 0], [0, 2]])

# (a)
vector_a = np.array([1, 1])
result_a = S.dot(vector_a)

# (b)
vector_b = np.array([1, 1])
result_b = S.dot(vector_b)

# (c)
vector_c = np.array([1, -1])
result_c = S.dot(vector_c)


# (d)
vector_d = np.array([1, 1])
result_d = S.dot(vector_d)

print("Result (a):", result_a)
print("Result (b):", result_b)
print("Result (c):", result_c)
print("Result (d):", result_d)
