import numpy as np
import matplotlib.pyplot as plt

P = np.array([1, 1])
Q = np.array([3, 1])
R = np.array([1, 3])
I = np.eye(2)

transformation_matrix = -1 * I
transformed_P = np.matmul(transformation_matrix, P)
transformed_Q = np.matmul(transformation_matrix, Q)
transformed_R = np.matmul(transformation_matrix, R)
plt.plot([P[0], Q[0], R[0], P[0]], [P[1], Q[1], R[1], P[1]], 'b-', label = 'PQR')

plt.plot([transformed_P[0], transformed_Q[0], transformed_R[0], transformed_P[0]], [transformed_P[1], transformed_Q[1], transformed_R[1], transformed_P[1]], 'r-', label = '(-I)PQR')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Triangle PQR and its Image')
plt.grid(True)
plt.axis('equal')
plt.show()
plt.legend()