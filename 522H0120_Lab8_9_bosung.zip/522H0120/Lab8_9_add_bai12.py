import numpy as np
from scipy.stats import linregress

# Given data
x = np.array([2015, 2016, 2017, 2018, 2019])
y = np.array([12, 19, 29, 37, 45])

# Perform linear regression
slope, intercept, r_value, p_value, std_err = linregress(x, y)

# Estimate the sales in the year 2020
year_2020 = 2020
sales_2020 = slope * year_2020 + intercept

print("Estimated sales in 2020:", sales_2020)
