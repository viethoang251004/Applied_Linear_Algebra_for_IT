import numpy as np
import matplotlib.pyplot as plt

mileage = np.array([2000, 6000, 20000, 30000, 40000])
friction_index = np.array([20, 18, 10, 6, 2])

A = np.vstack([mileage, np.ones(len(mileage))]).T
b = friction_index

a, b = np.linalg.lstsq(A, b, rcond=None)[0]

plt.scatter(mileage, friction_index, color='blue', label='Data Points')
plt.plot(mileage, a*mileage + b, color='red', label='Approximated Line')
plt.xlabel('Mileage')
plt.ylabel('Friction Index')
plt.legend()
plt.show()

print(f"The equation of the approximated line is: y = {a:.2f}x + {b:.2f}")
