import numpy as np
import matplotlib.pyplot as plt

data_points = np.array([[1, 7.9], [2, 5.4], [3, -9]])

def find_least_squares_fit(data):
    x = data[:, 0]
    y = data[:, 1]
    A = np.vstack([np.cos(x), np.sin(x)]).T
    a, b = np.linalg.lstsq(A, y, rcond=None)[0]
    return a, b

x_values = np.linspace(0, 4, 100)

a, b = find_least_squares_fit(data_points)
y_values = a * np.cos(x_values) + b * np.sin(x_values)

plt.scatter(data_points[:, 0], data_points[:, 1], label='Data Points')
plt.plot(x_values, y_values, label='Least Squares Fit')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.show()
