import numpy as np

A = np.array([[1, 2], [0, -3], [2, 6]])
b = np.array([1, 1, 0])

# Calculate the least squares solution
x, _, _, _ = np.linalg.lstsq(A, b, rcond=None)

# Compute the vector in the column space of A
result = A @ x

print("Vector in the column space of A closest to b:")
print(result)
