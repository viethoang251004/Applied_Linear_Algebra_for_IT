import numpy as np

A = np.array([[2, 2], [2, 3]])
b = np.array([4, 6])

# Tìm giải pháp bình phương tối thiểu
x, residuals, rank, s = np.linalg.lstsq(A, b, rcond=None)

print("Least square solution:")
print(x)
