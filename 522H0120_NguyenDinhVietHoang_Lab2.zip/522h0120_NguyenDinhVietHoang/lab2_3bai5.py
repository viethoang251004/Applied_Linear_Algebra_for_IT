import numpy as np

Y = np.array([[1, 2, 16, 31, 22],
              [2, 8, 12, 21, 23],
              [4, 9, 11, 14, 25],
              [3, 6, 10, 16, 34]])

# a) Vector x
x = Y[1, [1, 2, 3]]
print(x)

# b) Vector y
y = Y[[0, 1, 2, 3], [2, 2, 2, 2]].reshape(-1, 1)
print(y)

# c) Matrix A
A = Y[1:3, 1:4]
print(A)

# d) Matrix B
B = Y[:, [0, 2, 4]]
print(B)

# e) Matrix C
C = Y[1:, 1:5:2]
print(C)

# f) Matrix D
D = np.where(Y > 12, Y, 0)
print(D)