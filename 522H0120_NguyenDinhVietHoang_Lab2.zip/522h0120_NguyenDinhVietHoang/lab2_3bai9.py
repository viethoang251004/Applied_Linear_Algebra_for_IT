import numpy as np

# Define the transition matrix T and the probability vector p
T = np.array([[0.6, 0.7],
              [0.4, 0.3]])
p = np.array([[0.5],
              [0.5]])

# Define the values of k for which we want to calculate pk
k_values = [1, 2, 10, 100, 100000]

# Calculate pk for each value of k and print the results
for k in k_values:
    pk = np.linalg.matrix_power(T, k) @ p
    print("k =", k)
    print(pk)
    print()