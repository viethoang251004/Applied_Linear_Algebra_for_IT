import numpy as np

# Set seed for reproducibility
np.random.seed(1)

# Generate random matrices A and B of various sizes
A1 = np.random.rand(2, 2)
B1 = np.random.rand(2, 2)

A2 = np.random.rand(3, 3)
B2 = np.random.rand(3, 3)

A3 = np.random.rand(4, 4)
B3 = np.random.rand(4, 4)

A4 = np.random.rand(5, 5)
B4 = np.random.rand(5, 5)

# Compute the determinants of A and B separately
det_A1 = np.linalg.det(A1)
det_B1 = np.linalg.det(B1)

det_A2 = np.linalg.det(A2)
det_B2 = np.linalg.det(B2)

det_A3 = np.linalg.det(A3)
det_B3 = np.linalg.det(B3)

det_A4 = np.linalg.det(A4)
det_B4 = np.linalg.det(B4)

# Compute the determinant of the product AB
det_AB1 = np.linalg.det(np.dot(A1, B1))
det_AB2 = np.linalg.det(np.dot(A2, B2))
det_AB3 = np.linalg.det(np.dot(A3, B3))
det_AB4 = np.linalg.det(np.dot(A4, B4))

# Compare the determinants
print("det(A1)*det(B1) =", det_A1 * det_B1, "  det(AB1) =", det_AB1)
print("det(A2)*det(B2) =", det_A2 * det_B2, "  det(AB2) =", det_AB2)
print("det(A3)*det(B3) =", det_A3 * det_B3, "  det(AB3) =", det_AB3)
print("det(A4)*det(B4) =", det_A4 * det_B4, "  det(AB4) =", det_AB4)