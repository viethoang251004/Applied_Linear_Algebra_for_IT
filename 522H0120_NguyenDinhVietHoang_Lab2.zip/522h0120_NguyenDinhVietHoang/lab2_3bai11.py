import numpy as np

A = np.array([[2, 4, 1], [6, 7, 2], [3, 5, 9]])

#(a)
print("A is a square matrix because it has the same number of rows and columns.")

#(b)
A_T = A.T
print(A_T)

#(c)
A_skew = -A.T
print(np.array_equal(A, A_skew)) # False
print("It is not skew-symmetric.")

#(d)
U = np.triu(A)
print(U)

#(e)
L = np.tril(A)
print(L)