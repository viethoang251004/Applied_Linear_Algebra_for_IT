import numpy as np

A = np.array([[-1, 4, 8], [-9, 1, 2]])
B = np.array([[5, 8], [0, -6], [5, 6]])
C = np.array([[-4, 1], [6, 5]])
D = np.array([[-6, 3, 1], [8, 9, -2], [6, -1, 5]])

#(b)
BCt = np.dot(B, C.T)
print(BCt)

#(c)
C_Ct = C - C.T
print(C_Ct)

#(d)
D_Dt = D - D.T
print(D_Dt)

#(e)
Dt_t = D.T.T
print(Dt_t)

#(f)
two_Ct = 2 * C.T
print(two_Ct)

#(g)
At_B = A.T + B
print(At_B)

#(h)
At_Bt = (A.T + B).T
print(At_Bt)

#(i)
two_At_5Bt = (2 * A.T - 5 * B).T
print(two_At_5Bt)

#(j)
neg_Dt = (-D).T
print(neg_Dt)

#(k)
negDt = -(D.T)
print(negDt)

#(l)
C2t = (C**2).T
print(C2t)

#(m)
Ct2 = np.dot(C.T, C.T)
print(Ct2)